#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("hello world!");
	getchar();
}